import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Tetris extends PApplet {

int rows, cols, cellSize = 25;
Shape S;
Cell[][] cells;

public void setup()
{
  
  rows = height / cellSize;
  cols = width / cellSize;
  cells = new Cell[cols][rows];
  colorMode(HSB);
  for (int i = 0; i < cells.length; i++)
  {
    for (int j = 0; j < cells[i].length; j++)
    {
      cells[i][j] = new Cell(i, j, false);
    }
  }
  S = new Shape();
}

public void draw()
{
  background(50);
  if (frameCount % 10 == 0)
  {
    S.moveDown();
  }

  for (int j = 0; j < cells[0].length; j++)
  {
    boolean rowCleared = true; // Assume true; prove it wrong
    for (int i = cells.length - 1; i >= 0; i--) // Go in reverse order, bottom to top
    {                                           // This is so we can grab the above row, if multiple are deleted...
      cells[i][j].show();
      if (cells[i][j].filled == false)
      {
        rowCleared = false;
      }
    }
    if (rowCleared) // A Whole row had boxes in every square
    {
      for (int k = j; k > 0; k--)
      {
        for (int l = 0; l < cells.length; l++)
        {
          cells[l][k].filled = cells[l][k-1].filled;
          cells[l][k].col = cells[l][k-1].col;
        }
      }
    }
  }
  S.show();
}

public void keyPressed()
{
  if (key == 'A' || key == 'a')
  {
    S.moveLeft();
  }
  if (key == 'D' || key == 'd')
  {
    S.moveRight();
  }
  if (key == 'Z' || key == 'z' || keyCode == RIGHT)
  {
    S.rotateLeft();
  }
  if (key == 'X' || key == 'x' || keyCode == LEFT)
  {
    S.rotateRight();
  }
  if (key == 'S' || key == 's')
  {
    S.moveDown();
  }
  if (key == ' ')
  {
    S.crashDown();
  }
}

class Cell
{
  boolean filled;
  int col;
  int x, y;

  Cell(int _x, int _y, boolean _filled)
  {
    x = _x;
    y = _y;
    filled = _filled;
    col = color(50);
  }

  public void show()
  {
    strokeWeight(1);
    if (filled == true)
    {
      strokeWeight(3);
    }
    stroke(0);
    fill(col);
    rect(x * cellSize, y * cellSize, cellSize, cellSize);
  }
}

class Shape
{
  Cell[] boxes = new Cell[4]; //Tetris shapes all have 4 squares
  Shape()
  {
    getNewShape();
  }

  public boolean moveDown()
  {
    boolean goodToGo = true;
    for (int i = 0; i < 4; i++)
    {
      if (boxes[i].y >= rows-1 || cells[boxes[i].x][boxes[i].y+1].filled)
      {
        goodToGo = false;
        break;
      }
    }

    for (int i = 0; i < 4 && goodToGo; i++)
    {
      boxes[i].y++;
    }

    if (goodToGo == false)
    {
      for (int i = 0; i < 4; i++)
      {
        int _x = boxes[i].x;
        int _y = boxes[i].y;
        cells[_x][_y].filled = true;
        cells[_x][_y].col = boxes[i].col;
      }
      getNewShape();
    }
    return goodToGo;
  }

  public void getNewShape()
  {
    boxes[0] = new Cell(cols/2, 0, true); // All have a base cell
    int type = floor(random(7));
    switch(type)
    {
    case 0: // I shape
      boxes[1] = new Cell(cols/2 - 2, 0, true);
      boxes[2] = new Cell(cols/2 - 1, 0, true);
      boxes[3] = new Cell(cols/2 + 1, 0, true);
      break;
    case 1: // J shape
      boxes[1] = new Cell(cols/2 - 1, -1, true);
      boxes[2] = new Cell(cols/2 - 1, 0, true);
      boxes[3] = new Cell(cols/2 + 1, 0, true);
      break;
    case 2: // L shape
      boxes[1] = new Cell(cols/2 - 1, 0, true);
      boxes[2] = new Cell(cols/2 + 1, -1, true);
      boxes[3] = new Cell(cols/2 + 1, 0, true);
      break;
    case 3: // O shape
      boxes[1] = new Cell(cols/2 - 1, 0, true);
      boxes[2] = new Cell(cols/2 - 1, -1, true);
      boxes[3] = new Cell(cols/2, -1, true);
      break;
    case 4: // S shape
      boxes[1] = new Cell(cols/2 - 1, 0, true);
      boxes[2] = new Cell(cols/2, -1, true);
      boxes[3] = new Cell(cols/2 + 1, -1, true);
      break;
    case 5: // T shape
      boxes[1] = new Cell(cols/2, -1, true);
      boxes[2] = new Cell(cols/2 - 1, -1, true);
      boxes[3] = new Cell(cols/2 + 1, -1, true);
      break;
    case 6: // Z shape
      boxes[1] = new Cell(cols/2 + 1, 0, true);
      boxes[2] = new Cell(cols/2, -1, true);
      boxes[3] = new Cell(cols/2 - 1, -1, true);
      break;
    }
    for (int i = 0; i < 4; i++)
    {
      boxes[i].col = color(map(type, 0, 7, 0, 255), 255, 255);
      boxes[i].filled = true;
    }
  }

  public void moveLeft()
  {
    boolean goodToGo = true;
    for (int i = 0; i < 4; i++)
    {
      if (boxes[i].y >= 0 && (boxes[i].x <= 0 || cells[boxes[i].x-1][boxes[i].y].filled))
      {
        goodToGo = false;
        break;
      }
    }

    for (int i = 0; i < 4 && goodToGo; i++)
    {
      boxes[i].x--;
    }
  }

  public void rotateLeft()
  {
    boolean goodToGo = true;
    for (int i = 1; i < 4; i++) // Starting at 1 since 0 doesn't move
    {
      int dx = (boxes[i].x - boxes[0].x); // Changes in x and y
      int dy = (boxes[i].y - boxes[0].y);
      int x = boxes[0].x - dy; // To rotate, add deltas to oposite axis
      int y = boxes[0].y + dx;
      if (x < 0 || x >= cols || y < 0 || y >= rows || cells[x][y].filled == true)
      {
        goodToGo = false;
      }
    }
    for (int i = 1; i < 4 && goodToGo; i++) // Starting at 1 since 0 doesn't move
    {
      int dx = (boxes[i].x - boxes[0].x); // Changes in x and y
      int dy = (boxes[i].y - boxes[0].y);
      int x = boxes[0].x - dy; // To rotate, add deltas to oposite axis
      int y = boxes[0].y + dx;
      boxes[i].x = x;
      boxes[i].y = y;
    }
  }

  public void moveRight()
  {
    boolean goodToGo = true;
    for (int i = 0; i < 4; i++)
    {
      if (boxes[i].y >= 0 && (boxes[i].x >= cols - 1 || cells[boxes[i].x+1][boxes[i].y].filled))
      {
        goodToGo = false;
        break;
      }
    }

    for (int i = 0; i < 4 && goodToGo; i++)
    {
      boxes[i].x++;
    }
  }

  public void rotateRight()
  {
    boolean goodToGo = true;
    for (int i = 1; i < 4; i++) // Starting at 1 since 0 doesn't move
    {
      int dx = (boxes[i].x - boxes[0].x); // Changes in x and y
      int dy = (boxes[i].y - boxes[0].y);
      int x = boxes[0].x + dy; // To rotate, add deltas to oposite axis
      int y = boxes[0].y - dx;
      if (x < 0 || x >= cols || y < 0 || y >= rows || cells[x][y].filled == true)
      {
        goodToGo = false;
      }
    }
    for (int i = 1; i < 4 && goodToGo; i++) // Starting at 1 since 0 doesn't move
    {
      int dx = (boxes[i].x - boxes[0].x); // Changes in x and y
      int dy = (boxes[i].y - boxes[0].y);
      int x = boxes[0].x + dy; // To rotate, add deltas to oposite axis
      int y = boxes[0].y - dx;
      boxes[i].x = x;
      boxes[i].y = y;
    }
  }

  public void crashDown()
  {
    boolean canGoDown = true;
    while (canGoDown)
    {
      canGoDown = moveDown();
    }
  }

  public void show()
  {
    for (int i = 0; i<4; i++)
    {
      boxes[i].show();
    }
  }
}

  public void settings() {  size(500, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Tetris" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
